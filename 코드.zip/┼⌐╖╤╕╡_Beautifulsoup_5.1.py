
from urllib.request import urlopen
from bs4 import BeautifulSoup

html=urlopen("http://www.abc.co.kr")

bsObj = BeautifulSoup(html.read(), "html.parser")

bsObj.h1




from urllib.request import urlopen
from bs4 import BeautifulSoup

html=urlopen("http://www.abc.co.kr")

bsObj = BeautifulSoup(html.read(), "html.parser")

List = bsObj.findAll("span",{"class":"yellow"})

for i in List:
    print(i.get_text())



from bs4 import BeautifulSoup 
import requests 
import re 
import sys 
import pprint

List=[] 

url="https://news.naver.com/main/read.nhn?mode=LSD&mid=shm&sid1=102&oid=001&aid=0010630211"

oid=url.split("oid=")[1].split("&")[0] 
aid=url.split("aid=")[1] 
page=1     
header = { 
    "User-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36", 
    "referer":url, 
     
} 

while True : 
    c_url="https://apis.naver.com/commentBox/cbox/web_neo_list_jsonp.json?ticket=news&templateId=default_society&pool=cbox5&_callback=jQuery1707138182064460843_1523512042464&lang=ko&country=&objectId=news"+oid+"%2C"+aid+"&categoryId=&pageSize=20&indexSize=10&groupId=&listType=OBJECT&pageType=more&page="+str(page)+"&refresh=false&sort=FAVORITE"  
# 파싱하는 단계입니다.
    r=requests.get(c_url,headers=header) 
    cont=BeautifulSoup(r.content,"html.parser")     
    total_comm=str(cont).split('comment":')[1].split(",")[0] 
   
    match=re.findall('"contents":([^\*]*),"userIdNo"', str(cont)) 
# 댓글을 리스트에 중첩합니다.
    List.append(match) 
# 한번에 댓글이 20개씩 보이기 때문에 한 페이지씩 몽땅 댓글을 긁어 옵니다.
    if int(total_comm) <= ((page) * 20): 
        break 
    else :  
        page+=1

def flatten(l): 
    flatList = [] 
    for elem in l: 
        # if an element of a list is a list 
        # iterate over this list and add elements to flatList  
        if type(elem) == list: 
            for e in elem: 
                flatList.append(e) 
        else: 
            flatList.append(elem) 
    return flatList

flatten(List)


 
 
 
 
import requests
from bs4 import BeautifulSoup
import json
import re
import sys
import time, random

def get_news(n_url):
    news_detail = []
    print(n_url)
    breq = requests.get(n_url)
    bsoup = BeautifulSoup(breq.content, 'html.parser')

    # 제목 파싱
    title = bsoup.select('h3#articleTitle')[0].text
    news_detail.append(title)

    # 날짜
    pdate = bsoup.select('.t11')[0].get_text()[:11]
    news_detail.append(pdate)

    # news text
    _text = bsoup.select('#articleBodyContents')[0].get_text().replace('\n', " ")
    btext = _text.replace("// flash 오류를 우회하기 위한 함수 추가 function _flash_removeCallback() {}", "")
    news_detail.append(btext.strip())

    # 신문사
    pcompany = bsoup.select('#footer address')[0].a.get_text()
    news_detail.append(pcompany)

    return news_detail

columns = ['날짜','신문사', '제목','내용']
df = pd.DataFrame(columns=columns)


query = '접경지'   # url 인코딩 에러는 encoding parse.quote(query) 

s_date = "2000.01.01" 

e_date = "2018.12.10" 

s_from = s_date.replace(".","") 

e_to = e_date.replace(".","") 

page = 1 

while True:
    
    time.sleep(random.sample(range(3), 1)[0])
    print(page) 
    
    url = "https://search.naver.com/search.naver?where=news&query=" + query + "&sort=1&field=1&ds=" + s_date + "&de=" + e_date +\
    "&nso=so%3Ar%2Cp%3Afrom" + s_from + "to" + e_to + "%2Ca%3A&start=" + str(page) 


    header = { 

        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36' 

    }
    
    
    req = requests.get(url,headers=header) 

    print(url) 

    cont = req.content 
    
    
    soup = BeautifulSoup(cont, 'html.parser') 


    if soup.findAll("a",{"class":"_sp_each_url"}) == [] :

        break 

    for urls in soup.findAll("a",{"class":"_sp_each_url"}): 

        try : 
           

            if urls.attrs["href"].startswith("https://news.naver.com"): 

                print(urls.attrs["href"]) 

                news_detail = get_news(urls.attrs["href"]) 

                    

                df=df.append(pd.DataFrame([[news_detail[1], news_detail[3], news_detail[0], news_detail[2]]],columns=columns))

        except Exception as e: 

            print(e)  

            continue 

    page += 10   
