
# coding: utf-8




html_str ="""
<html>
    <head>
        <title>안녕하세요</title>
    </head>
    <body>
        <h1>반갑습니다</h1>
            <div>테스트입니다.
                <span class="yellow">노랑1</span>
                <span class="yellow">노랑2</span>
                <span class="red">빨강1</span>
                <span class="red">빨강2</span>
            </div>
    </body>
</html>
"""





with open("file.html", "w",encoding ='euc-kr') as file:
    file.write(html_str)





import lxml.html
from urllib.request import urlopen





tree=lxml.html.parse(urlopen("www.abc.co.kr"))










html=tree.getroot()




html.cssselect("span")[0].tag





html.cssselect("span")[0].text





html.cssselect("span")[0].attrib





for a in html.cssselect("span"):
    print(a.get('class'),a.text)





from lxml import html
import requests





link = "http://sdirwmp.org/contact-us"
response = requests.get(link) 
sourceCode = response.content 
htmlElem = html.document_fromstring(sourceCode) 





tdElems = htmlElem.cssselect("[valign=top]") #list of all td elems
for elem in tdElems:
    print(elem.text_content() )

