from selenium import webdriver
import time
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
import pandas as pd 

driver = webdriver.Chrome('C:/Users/user1/Downloads/chromedriver_win32/chromedriver.exe')

driver.get("https://www.instagram.com/explore/tags/감정노동/?hl=ko")

text=[]
image=[]
for i in range(100):
    html = driver.page_source
    soup=BeautifulSoup(html,'html.parser')
    List=soup.find_all("img")
    for j in range(len(List)):
        if (soup.find_all("img")[j]).has_attr('alt') and (soup.find_all("img")[j]).has_attr('src'):
            text.append(List[j]['alt'])
            image.append(List[j]['src'])
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(1)

df=(pd.DataFrame(list(zip(text, image)),columns=["텍스트","이미지"]))
df2=(df.drop_duplicates(['텍스트','이미지'], keep='first'))
final=df2

final



from selenium import webdriver
import time
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
import pandas as pd 
import time

driver = webdriver.Chrome('C:/Users/user1/Downloads/chromedriver_win32/chromedriver.exe') 
from selenium.webdriver.common.keys import Keys
base_url = 'https://www.flickr.com/'
driver.get(base_url)

query="서울 야경"

driver.find_element_by_id("search-field").send_keys(query)
driver.find_element_by_id("search-field").send_keys(Keys.ENTER)
time.sleep(3)

list_size_pre=0
list_size=0
while True:
    list_size_pre=list_size
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(3)
    url_list=driver.find_elements_by_class_name("overlay")
    list_size=len(url_list)
    if list_size == list_size_pre:
        try:
            driver.find_element_by_xpath("//*[contains(text(), '결과 자세히 알아보기')]").click()
        except Exception as e:
            break

url_list=driver.find_elements_by_class_name("overlay")
url_list2=[]
for i in url_list:
    url_list2.append(i.get_attribute("href"))

driver2 = webdriver.Chrome('C:/Users/user1/Downloads/chromedriver_win32/chromedriver.exe')

image=[]
tag=[]
comments=[]

for i in range(len(url_list2)):
    try:
        driver2.get(url_list2[i])
        driver2.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        html = driver2.page_source
        soup=BeautifulSoup(html,'html.parser')
        image.append(soup.find_all("img",{"class":"main-photo"})[0]['src'])
        time.sleep(3)
        if driver2.find_elements_by_class_name("tags-list") != []:
            tag.append((driver2.find_element_by_class_name("tags-list").text).replace("\n",","))
        else:
            tag.append(" ")
        if driver2.find_elements_by_class_name("comments") != []:
            comments.append((driver2.find_element_by_class_name("comments").text).replace("\n",","))
        else:
            comments.append("")
        if i % 10 == 0:
            print(str(i)+"번째 완료")
    except Exception as e:
        print(e)
    

