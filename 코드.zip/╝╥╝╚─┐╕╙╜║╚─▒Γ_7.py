
# coding: utf-8




#라이브러리 불러오기
import pandas as pd
from collections import Counter
from konlpy.tag import Kkma





# 형태소 분석기 실행
kkma = Kkma()





Data=pd.read_excel("E:\\파이썬으로텍스트마이닝분석\\데이터\\서울강남.xlsx")





Data.columns=['reveiw','date','score']





Data.head()





Data_high_score=Data.loc[Data['score']>4]





Data_low_score=Data.loc[Data['score']<2]





Data_high_score=Data_high_score.reset_index(drop=True)
Data_low_score=Data_low_score.reset_index(drop=True)





Data_high_score.head()





Data_low_score.head()





high_score_reviews = []
for i in range(len(Data_high_score)):
    try:
        high_score_reviews.append(kkma.nouns(Data_high_score["reveiw"][i]))
    except Exception as e:
        continue





low_score_reviews = []
for i in range(len(Data_low_score)):
    try:
        low_score_reviews.append(kkma.nouns(Data_low_score["reveiw"][i]))
    except Exception as e:
        continue



# 중첩 리스트 하나의 리스트로 변환하는 함수
def flatten(l): 
    flatList = [] 
    for elem in l: 
        if type(elem) == list: 
            for e in elem: 
                flatList.append(e) 
        else: 
            flatList.append(elem) 
    return flatList





high_score_reviews=flatten(high_score_reviews)
low_score_reviews=flatten(low_score_reviews)





high_score_reviews=[x for x in high_score_reviews if len(x)>1]





low_score_reviews=[x for x in low_score_reviews if len(x)>1]





high_score_reviews=[x for x in high_score_reviews if not x.isdigit()]





low_score_reviews=[x for x in low_score_reviews if not x.isdigit()]





pd.Series(high_score_reviews).value_counts().head(20)





pd.Series(low_score_reviews).value_counts().head(20)





from wordcloud import WordCloud
get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt





def __array__(self):
    """Convert to numpy array.
    Returns
    -------
    image : nd-array size (width, height, 3)
        Word cloud image as numpy matrix.
    """
    return self.to_array()

def to_array(self):
    """Convert to numpy array.
    Returns
    -------
    image : nd-array size (width, height, 3)
        Word cloud image as numpy matrix.
    """
    return np.array(self.to_image())





font_path = 'C:\\Users\\user1\\Desktop\\NanumBarunGothic.ttf'





wordcloud = WordCloud(
    font_path = font_path,
    width = 800,
    height = 800,
    background_color="Black",colormap="Oranges"
)





wordcloud = wordcloud.generate_from_frequencies(Counter(high_score_reviews))





array = wordcloud.to_array()





fig = plt.figure(figsize=(10, 10))
plt.imshow(array, interpolation="bilinear")
plt.show()





wordcloud = WordCloud(
    font_path = font_path,
    width = 800,
    height = 800,
    background_color="Black",colormap="hot_r"
)





wordcloud = wordcloud.generate_from_frequencies(Counter(low_score_reviews))





array = wordcloud.to_array()





fig = plt.figure(figsize=(10, 10))
plt.imshow(array, interpolation="bilinear")
plt.show()





[x for x in Data_high_score['reveiw'] if "친절" in x]





Data_high_score['reveiw'][0]





"냄새" in Data_low_score['reveiw']





from gensim import corpora, models
import gensim





high_score_reviews = []
for i in range(len(Data_high_score)):
    try:
        high_score_reviews.append(kkma.nouns(Data_high_score["reveiw"][i]))
    except Exception as e:
        continue





high_score_reviews=[[y for y in x if not len(y)==1] for x in high_score_reviews]





dictionary = corpora.Dictionary(high_score_reviews)





corpus = [dictionary.doc2bow(text) for text in high_score_reviews]





ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics=5, id2word = dictionary)




ldamodel.print_topics(num_words=10)





low_score_reviews = []
for i in range(len(Data_low_score)):
    try:
        low_score_reviews.append(kkma.nouns(Data_low_score["reveiw"][i]))
    except Exception as e:
        continue





low_score_reviews=[[y for y in x if not len(y)==1] for x in low_score_reviews]





dictionary = corpora.Dictionary(low_score_reviews)





corpus = [dictionary.doc2bow(text) for text in low_score_reviews]




ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics=10, id2word = dictionary)





ldamodel.print_topics(num_words=10)




Data_low_score["reveiw"][0]





low_score_reviews[0]





ldamodel.get_document_topics(corpus)[0]





from gensim.models.word2vec import Word2Vec




model = Word2Vec(high_score_reviews, sg=1, window=10,min_count=1)





model.init_sims(replace=True)





model.wv.most_similar("음식",topn =10)





model = Word2Vec(low_score_reviews, sg=1, window=10, min_count=1)





model.init_sims(replace=True)





model.wv.most_similar("음식",topn =10)

