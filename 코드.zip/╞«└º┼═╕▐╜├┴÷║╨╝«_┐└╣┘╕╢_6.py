ln [1]: from selenium import webdriver
from bs4 import BeautifulSoup
import requests
from selenium.webdriver.common.desired_capabilities import  DesiredCapabilities
import time
from selenium.webdriver.common.keys import Keys
import datetime as dt
import pandas as pd
from gensim.models import CoherenceModel
import matplotlib.pyplot as plt
import numpy as np
from gensim.models.word2vec import Word2Vec
from nltk.corpus import stopwords 
from nltk.stem.porter import PorterStemmer
from gensim import corpora, models
import gensim
from nltk.tokenize import RegexpTokenizer

driver = webdriver.Chrome('C:/Users/user1/Downloads/chromedriver_win32/chromedriver.exe')

startdate=dt.date(year=2018,month=12,day=1) #시작날짜
untildate=dt.date(year=2018,month=12,day=2) # 시작날짜 +1
enddate=dt.date(year=2018,month=12,day=2) # 끝날짜

query="Barack Obama"
totaltweets=[]
while not enddate==startdate:
    url='https://twitter.com/search?q='+query+'%20since%3A'+str(startdate)+'%20until%3A'+str(untildate)+'&amp;amp;amp;amp;amp;amp;lang=eg'
    driver.get(url)
    html = driver.page_source
    soup=BeautifulSoup(html,'html.parser')
    
    lastHeight = driver.execute_script("return document.body.scrollHeight")
    while True:
        
        dailyfreq={'Date':startdate}

        wordfreq=0
        tweets=soup.find_all("p", {"class": "TweetTextSize"})
                    
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1)
        newHeight = driver.execute_script("return document.body.scrollHeight")
        
        if newHeight != lastHeight:
            html = driver.page_source
            soup=BeautifulSoup(html,'html.parser')
            tweets=soup.find_all("p", {"class": "TweetTextSize"})
            wordfreq=len(tweets)
        else:
            dailyfreq['Frequency']=wordfreq
            wordfreq=0
            startdate=untildate
            untildate+=dt.timedelta(days=1)
            dailyfreq={}
            totaltweets.append(tweets)
            break

        lastHeight = newHeight

df_obama = pd.DataFrame(columns=['id','message'])

number=1
for i in range(len(totaltweets)):
    for j in range(len(totaltweets[i])):
        df_obama = df_obama.append({'id': number,'message':(totaltweets[i][j]).text}, ignore_index=True)
        number = number+1

len(df_obama)


df_obama.head()


tokenizer = RegexpTokenizer('[\w]+')

stop_words = stopwords.words('english')

doc_set_obama=list(df_obama['message'])

texts_obama = []

for w in doc_set_obama:
    raw = w.lower()
    tokens = tokenizer.tokenize(raw)
    stopped_tokens = [i for i in tokens if not i in (stop_words+["com","https"])]
    stopped_tokens2 = [i for i in stopped_tokens if len(i)>1]
    stopped_tokens3 = [i for i in stopped_tokens2 if i.isdigit() == False]
    texts_obama.append(stopped_tokens3)

dictionary = corpora.Dictionary(texts_obama)

corpus = [dictionary.doc2bow(text) for text in texts_obama]

coherence_values = []
for i in range(2,10):
    ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics=i, id2word = dictionary)
    coherence_model_lda = CoherenceModel(model=ldamodel, texts=texts_obama, dictionary=dictionary,topn=10)
    coherence_lda = coherence_model_lda.get_coherence()
    coherence_values.append(coherence_lda)

x = range(2,10)
plt.plot(x, coherence_values)
plt.xlabel("Number of topics")
plt.ylabel("coherence score")
plt.show()


ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics=2, id2word = dictionary)

ldamodel.print_topics(num_words=10)

NRC=pd.read_csv('E:\\파이썬으로텍스트마이닝분석\\데이터\\nrc.txt',engine="python",header=None,sep="\t")
NRC=NRC[(NRC != 0).all(1)]
NRC=NRC.reset_index(drop=True)

# 중첩 리스트 하나의 리스트로 변환하는 함수
def flatten(l): 
    flatList = [] 
    for elem in l: 
        if type(elem) == list: 
            for e in elem: 
                flatList.append(e) 
        else: 
            flatList.append(elem) 
    return flatList

match_words = [x for x in flatten(texts_obama) if x in list(NRC[0])]

emotion=[]
for i in match_words:
    temp=list(NRC.iloc[np.where(NRC[0] == i)[0],1])
    for j in temp:
        emotion.append(j)

sentiment_result1=pd.Series(emotion).value_counts()

sentiment_result1


sentiment_result1.plot.bar()



model = Word2Vec(texts_obama, sg=1, window=5, min_count=2)

model.init_sims(replace=True)

model.wv.most_similar("obama",topn = 10)
