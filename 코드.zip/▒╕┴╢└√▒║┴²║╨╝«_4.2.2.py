
# coding: utf-8




import pandas as pd
from konlpy.tag import Hannanum
from sklearn.feature_extraction.text import CountVectorizer
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot as plt
from sklearn.cluster import AgglomerativeClustering
import scipy.cluster.hierarchy as shc





hannanum = Hannanum()





Data = pd.read_csv('E:\\책쓰기\\군집분석데이터.csv',engine="python")




Data.head()





docs = []
for i in Data['기사내용']:
    docs.append(hannanum.nouns(i))





for i in range(len(docs)):
    docs[i] = ' '.join(docs[i])





vec = CountVectorizer()
X = vec.fit_transform(docs)





df = pd.DataFrame(X.toarray(), columns=vec.get_feature_names())





df





cluster = AgglomerativeClustering(n_clusters=3, linkage='ward')  
cluster.fit_predict(df)  





plt.figure(figsize=(10, 7))  
plt.title("Customer Dendograms")  
dend = shc.dendrogram(shc.linkage(df, method='ward'))

